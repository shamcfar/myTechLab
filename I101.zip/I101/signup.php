<?php
$title = 'Registration';
$style = '<link rel="stylesheet" href="styles/register.css" />';

require_once 'includes/header.php';
?>

<div id="body">
                <form id="registration">
                    <label><b>Username:</b></label>
                    <input type="text" placeholder="Enter username" name="username" required><br>
                    <label><b>e-mail:</b></label>
                    <input type="text" placeholder="Enter e-mail" name="email" required><br>
                    <label><b>Password:</b></label>
                    <input type="text" placeholder="Enter password" name="password" required><br>
                    <label><b>Confirm password:</b></label>
                    <input type="text" placeholder="Confirm password" name="confirmPass" required><br>
                    <input type="checkbox" checked="checked">Remember Me
                    
                    <p>By creating an account you agree to our <a href="#">Terms &amp; Privacy</a>.</p>
                    
                    <div class="clearfix">
                        <button type="button" class="cancelbtn">Cancel</button>
                        <button type="submit" class="signupbtn">Sign Up</button>
                    </div>
                </form>
            </div><!--body-->
            
<?php 
require_once 'includes/footer.php';