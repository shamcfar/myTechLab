        <footer>
           
            <pre>
                Follow us:<span style="margin-left: 40%;">&copy; MyTechLab.All Rights Reserved</span>
                <span style="color: #7FFFD4;">Twitter:</span><a style="color: white;" href="https://www.twitter.com/">@mytechlab</a>
                <span style="color: #DC134C;">Instagram:</span><a style="color: white;" href="https://www.instagram.com/">Mytechlab</a>
            </pre>
        </footer>

        <script src="js/app.js"></script>
    </body>
</html>