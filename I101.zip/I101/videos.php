<?php
$title = 'Video Help';
$style = '<link rel="stylesheet" href="styles/video.css" />';

require_once 'includes/header.php';
?>


<?php
require_once 'includes/footer.php';