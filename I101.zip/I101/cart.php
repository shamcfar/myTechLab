<?php
$title = "Shopping Cart";
$style = '<link rel="stylesheet" href="styles/cart.css" />';

require_once 'includes/header.php';
?>


<?php
require_once 'includes/footer.php';